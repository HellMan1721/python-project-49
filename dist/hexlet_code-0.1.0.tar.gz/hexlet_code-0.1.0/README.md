### Hexlet tests and linter status:
[![Actions Status](https://github.com/HellMan1721/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/HellMan1721/python-project-49/actions)

[![asciicast](https://asciinema.org/a/j1aAnCRIv36QE25FsFmORuWwG.svg)](https://asciinema.org/a/j1aAnCRIv36QE25FsFmORuWwG)

[![asciicast](https://asciinema.org/a/4QaHQ1TBq9UfWgEfet67OWkZV.svg)](https://asciinema.org/a/4QaHQ1TBq9UfWgEfet67OWkZV)

[![Maintainability](https://api.codeclimate.com/v1/badges/cb40db3089c07f703d4a/maintainability)](https://codeclimate.com/github/HellMan1721/python-project-49/maintainability)
