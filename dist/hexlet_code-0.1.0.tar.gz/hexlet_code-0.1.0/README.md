### Hexlet tests and linter status:
[![Actions Status](https://github.com/HellMan1721/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/HellMan1721/python-project-49/actions)

[![asciicast](https://asciinema.org/a/DXEBXmj5clCZOIOBpb1E6R2y0.svg)](https://asciinema.org/a/DXEBXmj5clCZOIOBpb1E6R2y0)

[![asciicast](https://asciinema.org/a/dWYPcdpQ8PKD5MSu74TMCLkkr.svg)](https://asciinema.org/a/dWYPcdpQ8PKD5MSu74TMCLkkr)

[![asciicast](https://asciinema.org/a/8hUr9TGnpUbBEtzG1zapPMbbc.svg)](https://asciinema.org/a/8hUr9TGnpUbBEtzG1zapPMbbc)

[![asciicast](https://asciinema.org/a/MUN7qRYKV4yiXuvHy4doDNxTj.svg)](https://asciinema.org/a/MUN7qRYKV4yiXuvHy4doDNxTj)

[![asciicast](https://asciinema.org/a/KWc0vaWHPH5Y4IrSEUebPPZZu.svg)](https://asciinema.org/a/KWc0vaWHPH5Y4IrSEUebPPZZu)

[![asciicast](https://asciinema.org/a/L1hyraQQR2RioE66aC143syjO.svg)](https://asciinema.org/a/L1hyraQQR2RioE66aC143syjO)

[![Maintainability](https://api.codeclimate.com/v1/badges/cb40db3089c07f703d4a/maintainability)](https://codeclimate.com/github/HellMan1721/python-project-49/maintainability)
