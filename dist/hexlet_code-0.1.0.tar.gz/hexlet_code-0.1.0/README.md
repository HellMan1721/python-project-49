### Hexlet tests and linter status:
[![Actions Status](https://github.com/HellMan1721/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/HellMan1721/python-project-49/actions)

[![asciicast](https://asciinema.org/a/j1aAnCRIv36QE25FsFmORuWwG.svg)](https://asciinema.org/a/j1aAnCRIv36QE25FsFmORuWwG)

[![asciicast](https://asciinema.org/a/XI3HT7SMKORaBN2uUp3hhx7g0.svg)](https://asciinema.org/a/XI3HT7SMKORaBN2uUp3hhx7g0)

[![asciicast](https://asciinema.org/a/tyzlQf8RZP0V4M88YkPqxjpnf.svg)](https://asciinema.org/a/tyzlQf8RZP0V4M88YkPqxjpnf)

[![asciicast](https://asciinema.org/a/9BJ204OelFsTT5L0ka8fQ0Vzi.svg)](https://asciinema.org/a/9BJ204OelFsTT5L0ka8fQ0Vzi)

[![asciicast](https://asciinema.org/a/PGoGjfq1eG6kQGZ3vhpiCVhKW.svg)](https://asciinema.org/a/PGoGjfq1eG6kQGZ3vhpiCVhKW)

[![Maintainability](https://api.codeclimate.com/v1/badges/cb40db3089c07f703d4a/maintainability)](https://codeclimate.com/github/HellMan1721/python-project-49/maintainability)
