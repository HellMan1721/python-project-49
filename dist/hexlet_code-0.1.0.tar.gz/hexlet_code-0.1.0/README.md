### Hexlet tests and linter status:
[![Actions Status](https://github.com/HellMan1721/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/HellMan1721/python-project-49/actions)

[![asciicast](https://asciinema.org/a/iOprKbfBCYpJf6UAQZHuyViGK.svg)](https://asciinema.org/a/iOprKbfBCYpJf6UAQZHuyViGK)

[![Maintainability](https://api.codeclimate.com/v1/badges/cb40db3089c07f703d4a/maintainability)](https://codeclimate.com/github/HellMan1721/python-project-49/maintainability)
