import brain_games.games.brain_even2 as be2
import brain_games.games.brain_calc as bc
import prompt


def main():

    print('Welcome to the Brain Games!')

    name = prompt.string('May I have your name? ')

    print('Hello, ' + name + '!')

    current_game = prompt.string('To select your Brain Game, plese enter the corresponding number:\n1. Even Numbers game.\n')

    if current_game == '1':

        print("Launching 'Even Numbers game'...")

    elif current_game == '2':

        print("Launching 'Brain Calculator game'...")

    else:

        print('No game assigned for that number.\nGoodbye!')

        return None

    counter = 0


    while counter != 3:

        if current_game == '1':

            brain_question = be2.even2()

            correct_answer = be2.even1(brain_question)

        elif current_game == '2':

            brain_question = bc.calc1(bc.ran_num1, bc.ran_oper, bc.ran_num2)

            correct_answer = bc.calc2(bc.ran_num1, bc.ran_oper, bc.ran_num2)

        user_input = prompt.string(f"Question: {brain_question}\n")

        if user_input == correct_answer:

            print('Correct!')

            counter += 1

        elif user_input != correct_answer:

            print(f"'{user_input}' is wrong answer ;(. Correct answer was '{correct_answer}'.")

            print(f"Let's try again, {name}!")

            counter = 0


    print ('Congratulations!')


if __name__ == '__main__':

    main()
